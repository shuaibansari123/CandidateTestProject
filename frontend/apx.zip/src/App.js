import logo from './logo.svg';
import './App.css';
import SignUpForm from './pages/SignUpForm';

function App() {
  return (
    <div className="">
     <SignUpForm/>
    </div>
  );
}

export default App;
